package com.javarush.task.task11.task1116;

/* 
Цепочка наследования
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Pet {

    }

    public class Cat extends Pet{

    }

    public class Dog extends Pet{

    }
}
