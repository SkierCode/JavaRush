package com.javarush.task.task11.task1119;

/* 
Четвертая правильная «цепочка наследования»
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class House {

    }

    public class Cat {

    }

    public class Car {

    }

    public class Dog {

    }
}