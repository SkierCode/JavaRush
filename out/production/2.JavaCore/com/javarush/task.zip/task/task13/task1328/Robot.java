package com.javarush.task.task13.task1328;

public class Robot extends AbstractRobot{


    public Robot(String name) {
        super(name);
    }


}
