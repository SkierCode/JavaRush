package com.javarush.task.task14.task1409;

public class SuspensionBridge implements Bridge {
    @Override
    public int getCarsCount() {
        return 1;
    }
}
