package com.javarush.task.task14.task1410;

public abstract class Drink {
    public void taste(){
        System.out.println("Вкусно");
    }
}
