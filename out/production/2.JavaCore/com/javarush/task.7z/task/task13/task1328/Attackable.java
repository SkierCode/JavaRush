package com.javarush.task.task13.task1328;

public interface Attackable {
    BodyPart attack();
}
