package com.javarush.task.task12.task1210;

/* 
Три метода и максимум
*/

public class Solution {
    public static void main(String[] args) {

    }

    //Напишите тут ваши методы
    public static int max(int a, int b){
        return a > b ? a : b;
    }

    public static long max(long a, long b){
        return a > b ? a : b;
    }

    public static double max(double a, double b){
        return a > b ? a : b;
    }
}
