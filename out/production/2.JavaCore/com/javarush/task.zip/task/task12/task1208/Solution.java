package com.javarush.task.task12.task1208;

/* 
Свобода печати
*/

public class Solution {
    public static void main(String[] args) {

    }

    //Напишите тут ваши методы

    public static void print (int a){

    }

    public static void print (String s){

    }

    public static void print (int a, int b){

    }

    public static void print (int a, String s){

    }

    public static void print (String s, int a){

    }
}
