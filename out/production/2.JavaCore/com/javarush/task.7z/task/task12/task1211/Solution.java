package com.javarush.task.task12.task1211;

/* 
Абстрактный класс Pet
*/

public class Solution {
    public static void main(String[] args) {

    }

    public static abstract class Pet {
        public String getName() {
            return "Я - котенок";
        }
    }

}
