package com.javarush.task.task12.task1217;

/* 
Лететь, бежать и плыть
*/

public class Solution {
    public static void main(String[] args) {

    }

//add interfaces here - добавь интерфейсы

    public interface CanFly{
        void haveWings();
    }

    public interface CanRun{
        void moveLegs();
    }

    public interface CanSwim{
        void moveArms();
    }

}
