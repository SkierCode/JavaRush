package com.javarush.task.task11.task1118;

/* 
Городское хозяйство
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Pet {

    }

    public class Cat extends Pet{

    }

    public class Car {

    }

    public class Dog extends Pet{

    }
}
