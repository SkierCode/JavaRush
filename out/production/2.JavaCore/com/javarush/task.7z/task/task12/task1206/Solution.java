package com.javarush.task.task12.task1206;

/* 
Выполняем перегрузку!
*/

public class Solution {
    public static void main(String[] args) {

    }

    //Напишите тут ваши методы
    public static void print(int a){

    }

    public static void print(String s){

    }
}
