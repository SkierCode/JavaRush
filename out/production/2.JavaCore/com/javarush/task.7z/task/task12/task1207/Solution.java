package com.javarush.task.task12.task1207;

/* 
Int и Integer
*/

public class Solution {
    public static void main(String[] args) {
        int a=0;
        Integer b=0;
        print(a);
        print(b);

    }

    //Напишите тут ваши методы
    public static void print(int a){

    }

    public static void print(Integer b){

    }
}
